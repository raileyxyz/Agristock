<?php

namespace App\Services;

use App\Enums\Status;
use App\Models\Product;
use App\Models\Category;

class ProductService
{
    public function __construct(
        private SkuGeneratorService $skuGenerator
    ) {}

    public function getProducts(array $filters)
    {
        return Product::query()
            ->with(['category', 'unit'])
            ->withSum('inventories as current_stock', 'remaining_quantity')
            ->search($filters['search'] ?? null)
            ->filterStatus($filters['status'] ?? null)
            ->filterCategories($filters['category'] ?? null)
            ->latest()
            ->paginate(15)
            ->withQueryString();
    }

    public function getStatistics(): array
    {
        return [
            'total' => Product::count(),
            'active' => Product::where('status', Status::ACTIVE->value)->count(),
            'archived' => Product::where('status', Status::ARCHIVED->value)->count(),
        ];
    }

    public function create(array $data): Product
    {
        if(empty($data['sku'])){
            $category = Category::findOrFail($data['category_id']);

            $data['sku'] = $this->skuGenerator->generate($category);
        }

        return Product::create($data);
    }

    public function update(Product $product, array $data): Product
    {
        $product->update($data);

        return $product;
    }

    public function archive(Product $product): void
    {
        $product->update(['status' => Status::ARCHIVED]);
    }
}
