<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class Inventory extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id',
        'user_id',
        'supplier_id',
        'quantity',
        'remaining_quantity',
        'batch_number',
        'expiry_date',
        'expiring_soon_notified_at',
        'expired_notified_at',
        'location',
        'notes',
    ];

    protected $casts = [
        'expiry_date' => 'date',
        'expiring_soon_notified_at' => 'datetime',
        'expired_notified_at' => 'datetime',
        'quantity' => 'decimal:2',
        'remaining_quantity' => 'decimal:2',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function adjustments()
    {
        return $this->hasMany(StockAdjustment::class);
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function scopeSearch($query, $search)
    {
        return $query->when($search, function ($query) use ($search) {
            $query->whereHas('product', function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%");
            })
            ->orWhere('batch_number', 'like', "%{$search}%")
            ->orWhere('location', 'like', "%{$search}%");
        });
    }

    public function scopeFilterCategory($query, $categoryId)
    {
        return $query->when($categoryId, function ($query) use ($categoryId) {
            $query->whereHas('product', fn($q) => $q->where('category_id', $categoryId));
        });
    }

    public function scopeFilterLocation($query, $location)
    {
        return $query->when($location, fn($query) => $query->where('location', $location));
    }

    public function scopeFilterSupplier($query, $supplierId)
    {
        return $query->when($supplierId, fn($q) => $q->where('supplier_id', $supplierId));
    }

    public function scopeInStock($query)
    {
        return $query->where('remaining_quantity', '>', 0);
    }

    public function scopeFilterStock($query, $stock)
    {
        return match ($stock) {
            'depleted' => $query->where('remaining_quantity', '<=', 0),
            'all' => $query,
            default => $query->inStock(),
        };
    }

    public function getFormattedQuantityAttribute(): string
    {
        $qty = $this->remaining_quantity;

        return $qty == floor($qty)
            ? number_format($qty, 0)
            : number_format($qty, 2);
    }

    public function getStockStatusAttribute(): array
    {
        $remaining = $this->remaining_quantity;
        $minimum = $this->product->minimum_stock ?? 0;
        $reorder = $this->product->reorder_point ?? 0;

        if ($remaining <= 0) {
            return [
                'label' => 'Out of Stock',
                'class' => 'bg-gray-100 text-gray-500 dark:bg-gray-800/60 dark:text-gray-400'
            ];
        }

        if ($remaining <= $minimum) {
            return [
                'label' => 'Critical',
                'class' => 'bg-red-50 text-red-600 dark:bg-red-950/50 dark:text-red-400'
            ];
        }

        if ($remaining <= $reorder) {
            return [
                'label' => 'Low Stock',
                'class' => 'bg-amber-50 text-amber-600 dark:bg-amber-950/50 dark:text-amber-400'
            ];
        }

        return [
            'label' => 'In Stock',
            'class' => 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        ];
    }

    public function getExpiryDisplayAttribute(): array
    {
        if (! $this->expiry_date) {
            return ['label' => '—', 'class' => 'text-gray-300'];
        }

        $daysLeft = now()->startOfDay()->diffInDays($this->expiry_date, false);

        if ($daysLeft < 0) {
            return ['label' => 'Expired', 'class' => 'text-red-600 font-semibold'];
        }

        if ($daysLeft == 0) {
            return ['label' => '0d', 'class' => 'text-red-600 font-semibold'];
        }

        if ($daysLeft <= 30) {
            return ['label' => $daysLeft . 'd', 'class' => 'text-yellow-500 font-medium'];
        }

        if ($daysLeft <= 60) {
            return ['label' => $daysLeft . 'd', 'class' => 'text-green-600 font-medium'];
        }

        return ['label' => $this->expiry_date->format('M d, Y'), 'class' => 'text-gray-500'];
    }

    public function getHasMovementAttribute(): bool
    {
        return bccomp((string) $this->quantity, (string) $this->remaining_quantity, 2) !== 0;
    }
}
